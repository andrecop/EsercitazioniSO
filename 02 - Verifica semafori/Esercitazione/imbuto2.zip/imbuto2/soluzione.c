/*
 * Riempire le parti qui sotto. Sono TUTTE NECESSARIE per avere
 * una valutazione positiva! 
 *
 * COMMENTO GENERALE:
 *
 * (scrivere una spiegazione generale della soluzione proposta
 * sensa scendere troppo in dettaglio)
 *
 * SINCRONIZZAZIONE:
 *
 * (spiegare in dettaglio come avviene la sincronizzazione indicando
 * il ruolo di ogni semaforo e/o variabile globale utilizzata)
 *
 * RICONDUZIONE A UN PROBLEMA STANDARD: 
 *
 * (la soluzione proposta e' simile a qualcuna studiata in classe?
 * quali somno le differenze?)
 *
 */
 
// dichiarazione semafori e variabili globali

// inizializza semafori e variabili
// ATTENZIONE dim è la dimensione del gruppo che deve entrare
// nell'imbuto.
void inizializza_sem(int dim) {
}
 
// distruggi i semafori
void distruggi_sem() {
}
 
// attende di entrare nell'imbuto
void entra_imbuto() {
}
 
// esce dall'imbuto
// ATTENZIONE usare una variabile intera condivisa per sapere 
// quante palline sono uscite (da proteggere con una sezione critica)!
void esci_imbuto() {
}

